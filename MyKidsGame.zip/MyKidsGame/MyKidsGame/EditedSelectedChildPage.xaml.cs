﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using MyKidsGame.ChildrenClasses;
using MyKidsGame.Model;


// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MyKidsGame
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>

    public sealed partial class EditedSelectedChildPage : Page
    {
        string getData = "";

        string idNum = "";
        string name = "";
        string surname = "";
        string age = "";
        string grade = "";
        string parentID = "";

        string msgs = "";

        RegisterChild regChild = null;
        ChildrenViewModel childrenViewModel = null;

        public EditedSelectedChildPage()
        {
            this.InitializeComponent();
        }


        //Display the ID of the parent currently logged in
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            regChild = new RegisterChild();
            try
            {
                base.OnNavigatedTo(e);
                regChild = (RegisterChild)e.Parameter;

                idNum = "" + regChild.Id;
                name = "" + regChild.Name;
                surname = "" + regChild.Surname;
                age = "" + regChild.Age;
                grade = "" + regChild.Grade;
                parentID = "" + regChild.ParentId;


                //Display Child details on load Code
                lblChildsID.Text = idNum;
                txtCurrentChildName.Text = name;
                txtCurrentChildSurname_.Text = surname;
                txtCurrentChildAge.Text = age;

                cbCurrentChildGrade.Items.Add(grade);
                cbCurrentChildGrade.Items.Add("");
                cbCurrentChildGrade.Items.Add("Grade 1");
                cbCurrentChildGrade.Items.Add("Grade 2");


                //displayChildsDetails(idNum, name, age, grade);
            }
            catch (Exception)
            {

            }


        }

        //Code for displaying MessageBox
        private async void messageBox(string msg)
        {
            var msgDisplay = new Windows.UI.Popups.MessageDialog(msg);
            await msgDisplay.ShowAsync();

        }


        public void displayChildsDetails(string id, string name, string age, string grade)
        {
            /*
            lblChildsID.Text = id;
            txtCurrentChildName.Text = name;
            txtCurrentChildAge.Text = age;

            cbCurrentChildGrade.Items.Add(grade);
            cbCurrentChildGrade.Items.Add("");
            cbCurrentChildGrade.Items.Add("grade1");
            cbCurrentChildGrade.Items.Add("grade2");
            */
        }

        private void btnProceed_Click(object sender, RoutedEventArgs e)
        {
            childrenViewModel = new ChildrenViewModel();
            string id = lblChildsID.Text;
            int convID = Convert.ToInt32(id);

            string newName = txtCurrentChildName.Text;
            string newSurname = txtCurrentChildSurname_.Text;
            string newAge = txtCurrentChildAge.Text;
            string getGrade = "" + cbCurrentChildGrade.SelectedItem;

            int result = 0;

            if ((!newSurname.Equals("")) && (!newSurname.Equals("")) && (!newAge.Equals("")) && (!getGrade.Equals("")))
            {

                int verifyNum;
                bool isNumerical = int.TryParse(newAge, out verifyNum);

                if (isNumerical == true)
                {
                    try
                    {
                        result = childrenViewModel.updateChildInfo(convID, parentID, newName, newSurname, newAge, getGrade);

                    }
                    catch (Exception)
                    {

                    }


                    if (result > 0)
                    {
                        int ConvParentIden = Convert.ToInt32(parentID);
                        this.Frame.Navigate(typeof(MenuPage), ConvParentIden);
                        string msg = "Child details update was successful!";
                        messageBox(msg);
                    }
                    else
                    {
                        string msg = "Couldn't update child information!";
                        messageBox(msg);
                    }
                }
                else
                {
                    msgs = "Please enter numeric characters only for the age!";
                    messageBox(msgs);
                }




            }
            else
            {
                msgs = "Please ensure that all fields are filled in before proceeding to update!";
                messageBox(msgs);
            }

        }



        private void btnBackToMenu_Click(object sender, RoutedEventArgs e)
        {
            int convParentId = Convert.ToInt32(parentID);
            this.Frame.Navigate(typeof(SelectChildToViewPage), convParentId);
        }

    }
}
